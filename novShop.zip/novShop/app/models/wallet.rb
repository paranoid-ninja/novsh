class Wallet < ApplicationRecord
  include ActiveRecord::Singleton
end
