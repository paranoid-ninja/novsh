class PayCode < ApplicationRecord
end
