class TreasureQuery
end
